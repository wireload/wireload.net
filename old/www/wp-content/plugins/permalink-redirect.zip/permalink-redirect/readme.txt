=== Permalink Redirect ===
Contributors: joostdevalk
Donate link: http://yoast.com/donate/
Tags: SEO, permalinks
Requires at least: 2.5
Tested up to: 2.5.3
stable tag: 1.0.1

Redirects all crap away from the end of the URL.

== Description ==
This plugin makes sure you don't have `?q=ek` or other weird variables in your URL's, by redirecting them all out.

* [Permalink Redirect](http://yoast.com/wordpress/permalink-redirect/).
* Read more about [WordPress SEO](http://yoast.com/articles/wordpress-seo/) so you can get the most out of this plugin.
* Check out the other [Wordpress plugins](http://yoast.com/wordpress/) by the same author.


== Installation ==

Installation:

1. Unzip the `permalink-redirect.zip` file. 
1. Upload the the `permalink-redirect` folder (not just the files in it!) to your `wp-contents/plugins` folder. If you're using FTP, use 'binary' mode.

Activate:

1. In your WordPress administration, go to the Plugins page.
1. Activate the Permalink Redirect plugin.

If you find any bugs or have any ideas, please mail me.