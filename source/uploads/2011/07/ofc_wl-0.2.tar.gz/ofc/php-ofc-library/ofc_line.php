<?php

class line extends line_base
{
	function line()
	{
		$this->type      = "line";
	}
}