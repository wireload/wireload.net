Google Webtoolkit Open Flash Chart library is here:

http://code.google.com/p/ofcgwt/
