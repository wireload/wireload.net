using System;
using System.Collections.Generic;
using System.Text;

namespace OpenFlashChart
{
    public class Bar3D:Chart<double >
    {

        public Bar3D()
        {
            this.ChartType = "bar_3d";
        }
    }
}
