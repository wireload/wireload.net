using System;
using System.Collections.Generic;
using System.Text;

namespace OpenFlashChart
{
    public class LineDot:LineBase
    {
        public LineDot()
        {
            this.ChartType = "line_dot";
        }
    }
}
