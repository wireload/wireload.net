Hello.

This is the Open Flash Chart source code.

Take a look around :-)

The test data is in the 'data-files' directory.

